package restaurant;

public class Mother extends Restaurant{
	public Mother(EatBehavior e) {
		food=e;
	}
	
	public Mother(PayBehavior p) {
		pay=p;
	}
	

}
