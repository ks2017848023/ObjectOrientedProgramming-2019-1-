package restaurant;

public class Father extends Restaurant {
	public Father(EatBehavior e) {
		food=e;
	}
	
	public Father(PayBehavior p) {
		pay=p;
	}
}
