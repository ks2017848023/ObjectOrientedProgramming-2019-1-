package restaurant;

public class Restaurant {
	EatBehavior food;
	PayBehavior pay;
	
	public void eat() {
		food.eat();
	}
	
	public void pay() {
		pay.pay();
	}
	
	public void eatBehavior(EatBehavior e) {
		food=e;
	}
	
	public void PayBehavior(PayBehavior p) {
		pay=p;
	}

}
