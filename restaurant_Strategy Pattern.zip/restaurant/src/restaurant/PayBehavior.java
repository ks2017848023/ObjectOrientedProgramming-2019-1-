package restaurant;

interface PayBehavior {
	abstract public void pay();
}
