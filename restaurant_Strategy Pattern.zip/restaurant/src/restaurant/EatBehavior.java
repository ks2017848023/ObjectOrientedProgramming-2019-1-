package restaurant;

public interface EatBehavior {
	abstract public void eat(); //  
	
}
