package restaurant;


public class EatHamburger implements EatBehavior {
	@Override
	public void eat() {
		System.out.println("�ܹ��ż���");
	}
}
