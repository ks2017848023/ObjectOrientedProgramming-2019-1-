package restaurant;

public class Brother extends Restaurant{
	public Brother(EatBehavior e) {
		food =e;
	}
	
	public Brother(PayBehavior p) {
		pay=p;
	}

}
