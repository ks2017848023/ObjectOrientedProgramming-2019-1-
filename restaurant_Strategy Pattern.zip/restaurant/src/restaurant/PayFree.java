package restaurant;

public class PayFree implements PayBehavior{

	@Override
	public void pay() {
		System.out.println("�����̿��");
		
	}

}
