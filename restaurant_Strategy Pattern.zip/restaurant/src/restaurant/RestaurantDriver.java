package restaurant;

import java.util.ArrayList;

public class RestaurantDriver {

	public static void main(String[] args) {
		ArrayList<Restaurant> restaurant = new ArrayList<Restaurant>();
		//Restaurant ��ü 
		restaurant.add(new Mother(new EatHamburger()));
		restaurant.add(new Father(new EatSandwich()));
		restaurant.add(new Sister(new EatHamburger()));
		restaurant.add(new Brother(new EatSandwich()));
		restaurant.add(new Dog(new EatDogFood()));
		/*
		restaurant.add( new Mother( new PayMid()));
		restaurant.add( new Father( new PayMid()));
		restaurant.add( new Sister( new PayMid()));
		restaurant.add( new Brother( new PayMid()));
		restaurant.add( new Dog( new PayMid()));
		*/
		for(int i=0; i<restaurant.size(); i++) {
			Restaurant r = (Restaurant)restaurant.get(i); //get(i) index��������
			//��ü��x ����ϰ� �ִ� ���� Ŭ������ �����ϴ� ���� ����. Restaurant
			r.eat();
		}
	}
}
