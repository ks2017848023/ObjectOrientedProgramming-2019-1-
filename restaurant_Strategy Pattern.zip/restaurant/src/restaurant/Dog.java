package restaurant;

public class Dog  extends Restaurant {
	public Dog(EatBehavior e) {
		food=e;
	}
	
	public Dog(PayBehavior p) {
		pay=p;
	}

}
