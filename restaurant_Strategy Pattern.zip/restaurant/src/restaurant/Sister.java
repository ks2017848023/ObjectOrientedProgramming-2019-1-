package restaurant;

public class Sister extends Restaurant {
	public Sister(EatBehavior e) {
		food=e;
	}
	
	public Sister(PayBehavior p) {
		pay=p;
	}
}
