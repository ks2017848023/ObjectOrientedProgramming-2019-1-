package myProject;

import static java.util.stream.Collectors.groupingBy;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


class Team implements Comparable<Team> {		

	String team;//��
	int game;//����
	int point;//����
	int win;//��
	int draw;//��
	int loss;//��
	int add;//����
	int sub;//����
	int diff;//����� goal difference
	
	Team(String team, int game, int point, int win,int draw,int loss,int add,int sub,int diff) {
		this.team = team;
		this.game = game;
		this.point = point;
		this.win=win;
		this.draw=draw;
		this.loss=loss;
		this.add=add;
		this.sub=sub;
		this.diff=diff;
	}

	String getTame() {
		return team;
	}

	int getGame() {
		return game;
	}

	int getPoint() {
		return point;
	}

	int getWin() {
		return win;
	}
	
	int getDraw() {
		return draw;
	}
	
	int getLoss() {
		return loss;
	}
	
	int getAdd() {
		return add;
	}
	
	int getSub() {
		return sub;
	}
	
	int getDiff() {
		return diff;
	}
	
	
	public String toString() {
		return String.format("[%6s] %28s | ���� %3d, �� %3d, �� %3d,�� %3d,���� %3d,���� %3d,����� %3d",
				point>=66 ? "�е���������" : "������", team, game, win,loss,draw,add,sub,diff);
	}

	enum League {
		league,not
		//��������,�ƴ�
	}

	@Override
	public int compareTo(Team s) {
		return this.point - s.point;
	}
}

public class myProject {
	public static ArrayList<Team> createArrayTeam(String file) {

		String line = "";
		String cvsSplitBy = ",";
		int n = 0; // index of Team[]
		ArrayList<Team> TeamArr = new ArrayList<Team>();
		
		String team;
		int game;//��
		int point;//����
		int win;//��
		int draw;//��
		int loss;//��
		int add;//����
		int sub;//����
		int diff;//����� goal difference
		
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			while ((line = br.readLine()) != null) {
				String[] tmp = line.split(cvsSplitBy);
				team = tmp[0];
				game = Integer.parseInt(tmp[1]);
				point = Integer.parseInt(tmp[2]);
				win = Integer.parseInt(tmp[3]);
				draw = Integer.parseInt(tmp[4]);
				loss = Integer.parseInt(tmp[5]);
				add = Integer.parseInt(tmp[6]);
				sub = Integer.parseInt(tmp[7]);
				diff = Integer.parseInt(tmp[8]);
				
				
				
				TeamArr.add(new Team(team, game, point, win, draw, loss, add, sub, diff));
				n = n + 1;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return TeamArr;

	}

	public static void main(String[] args) {
		String cvsFile = "C:\\Users\\kimmm\\Desktop\\premierLeague2018_19.csv";
		List<Team> team = createArrayTeam(cvsFile);
		ArrayList<Team> TeamArr = createArrayTeam(cvsFile);
		System.out.println("==============================<<premierLeague2018-19>>===============================");
		for (Team s : team)
			System.out.println(s);
		System.out.println("=====================================================================================");

		System.out.println("=====================================================================================");
		System.out.printf("%n==<< è�Ǿ� ���� ���� >>==%n");
		Map<Team.League, List<Team>> TeamByLeague = TeamArr.stream().collect(groupingBy( s -> {
			if (s.getDiff() >= 30) 
				return Team.League.league;
			else
				return Team.League.not;
		}));
		
		TreeSet<Team.League> keySet = new TreeSet<>(TeamByLeague.keySet());

		for (Team.League key : keySet) {
			System.out.println("[" + key + "]");

			for (Team s : TeamByLeague.get(key))
				System.out.println(s);
			System.out.println();
		}
		System.out.println("=====================================================================================");
		
		System.out.println("==<< ���� ���� >>==");
		Collections.sort(team);
		
		Collections.sort(team, Comparator.comparing(Team::getWin));
		for (Team s : team)
			System.out.println(s);
		
		System.out.println("=====================================================================================");
	}

}
